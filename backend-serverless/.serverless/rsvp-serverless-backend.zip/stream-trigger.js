exports.handler = function (event, context, callback) {
    console.log('trigger stream was called');
    var eventData = event.Records[0];
    console.log(eventData);
    callback(null, null);
};
//# sourceMappingURL=stream-trigger.js.map